public class Produk {
    private String nama;
    private String deskripsi;
    private double harga;
    private int jumlahStok;

    public Produk (String nama, String deskripsi, double harga, int jumlahStok) {
        this.nama = nama;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.jumlahStok = jumlahStok;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public double getHarga() {
        return harga;
    }

    public void setJumlahStok(int jumlahStok) {
        this.jumlahStok = jumlahStok;
    }

    public int getJumlahStok() {
        return jumlahStok;
    }

    public void getInfo() {
        System.out.println("Nama Produk: " + nama);
        System.out.println("Deskripsi: " + deskripsi);
        System.out.println("Harga: Rp " + harga);
        System.out.println("Jumlah Stok: " + jumlahStok + " unit");
    }

    public static void main(String[] args) {
        Produk produk1 = new Produk ("Laptop", "Laptop dengan prosesor Intel Core i7", 10000000, 5);
        Produk produk2 = new Produk ("Mouse", "Mouse optik dengan 6 tombol", 200000, 10);

        System.out.println("Informasi Produk 1:");
        produk1.getInfo();

        System.out.println("\nInformasi Produk 2:");
        produk2.getInfo();
    }
}
