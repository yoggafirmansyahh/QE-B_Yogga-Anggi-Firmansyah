import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Scanner;

class Book {
    private UUID id;
    private String judul;
    private String penulis;
    private String kategori;

    public Book(String judul, String penulis, String kategori) {
        this.id = UUID.randomUUID();
        this.judul = judul;
        this.penulis = penulis;
        this.kategori = kategori;
    }

    public UUID getId() {
        return id;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getPenulis() {
        return penulis;
    }

    public void setPenulis(String penulis) {
        this.penulis = penulis;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    @Override
    public String toString() {
        return "ID: " + id + "\nJudul: " + judul + "\nPenulis: " + penulis + "\nKategori: " + kategori + "\n";
    }
}

public class BookStore {
    private List<Book> books = new ArrayList<>();

    public void createBook(String judul, String penulis, String kategori) {
        Book newBook = new Book(judul, penulis, kategori);
        books.add(newBook);
    }

    public List<Book> getAllBooks() {
        return books;
    }

    public Book getBookById(UUID id) {
        for (Book book : books) {
            if (book.getId().equals(id)) {
                return book;
            }
        }
        return null;
    }

    public void updateBook(UUID id, String newJudul, String newPenulis, String newKategori) {
        for (Book book : books) {
            if (book.getId().equals(id)) {
                book.setJudul(newJudul);
                book.setPenulis(newPenulis);
                book.setKategori(newKategori);
            }
        }
    }

    public void deleteBook(UUID id) {
        Book bookToRemove = null;
        for (Book book : books) {
            if (book.getId().equals(id)) {
                bookToRemove = book;
                break;
            }
        }
        if (bookToRemove != null) {
            books.remove(bookToRemove);
        }
    }

    public static void main(String[] args) {
        BookStore bookstore = new BookStore();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Pilih operasi:");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Tampilkan Semua Buku");
            System.out.println("3. Cari Buku Berdasarkan ID");
            System.out.println("4. Update Buku Berdasarkan ID");
            System.out.println("5. Hapus Buku Berdasarkan ID");
            System.out.println("6. Keluar");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Membuang newline

            switch (choice) {
                case 1:
                    System.out.print("Judul: ");
                    String judul = scanner.nextLine();
                    System.out.print("Penulis: ");
                    String penulis = scanner.nextLine();
                    System.out.print("Kategori: ");
                    String kategori = scanner.nextLine();
                    bookstore.createBook(judul, penulis, kategori);
                    System.out.println("Buku telah ditambahkan.");
                    break;
                case 2:
                    List<Book> allBooks = bookstore.getAllBooks();
                    System.out.println("Daftar Buku:");
                    for (Book book : allBooks) {
                        System.out.println(book);
                    }
                    break;
                case 3:
                    System.out.print("Masukkan ID Buku: ");
                    String bookIdStr = scanner.nextLine();
                    try {
                        UUID bookId = UUID.fromString(bookIdStr);
                        Book foundBook = bookstore.getBookById(bookId);
                        if (foundBook != null) {
                            System.out.println("Informasi Buku:");
                            System.out.println(foundBook);
                        } else {
                            System.out.println("Buku dengan ID tersebut tidak ditemukan.");
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println("Format ID Buku tidak valid.");
                    }
                    break;
                case 4:
                    System.out.print("Masukkan ID Buku yang akan diupdate: ");
                    String updateIdStr = scanner.nextLine();
                    try {
                        UUID updateId = UUID.fromString(updateIdStr);
                        Book foundBook = bookstore.getBookById(updateId);
                        if (foundBook != null) {
                            System.out.print("Judul Baru: ");
                            String newJudul = scanner.nextLine();
                            System.out.print("Penulis Baru: ");
                            String newPenulis = scanner.nextLine();
                            System.out.print("Kategori Baru: ");
                            String newKategori = scanner.nextLine();
                            bookstore.updateBook(updateId, newJudul, newPenulis, newKategori);
                            System.out.println("Buku telah diupdate.");
                        } else {
                            System.out.println("Buku dengan ID tersebut tidak ditemukan.");
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println("Format ID Buku tidak valid.");
                    }
                    break;
                case 5:
                    System.out.print("Masukkan ID Buku yang akan dihapus: ");
                    String deleteIdStr = scanner.nextLine();
                    try {
                        UUID deleteId = UUID.fromString(deleteIdStr);
                        Book foundBook = bookstore.getBookById(deleteId);
                        if (foundBook != null) {
                            bookstore.deleteBook(deleteId);
                            System.out.println("Buku telah dihapus.");
                        } else {
                            System.out.println("Buku dengan ID tersebut tidak ditemukan.");
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println("Format ID Buku tidak valid.");
                    }
                    break;
                case 6:
                    System.out.println("Terima kasih!");
                    System.exit(0);
                default:
                    System.out.println("Pilihan tidak valid. Silakan pilih lagi.");
            }
        }
    }
}
