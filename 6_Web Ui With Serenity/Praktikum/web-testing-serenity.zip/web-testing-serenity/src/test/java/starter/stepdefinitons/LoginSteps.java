package starter.stepdefinitons;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.LoginPage;
import starter.pages.ProductPage;

public class LoginSteps {

    @Steps
    LoginPage loginPage;

    @Steps
     ProductPage productPage;

    @Given("User berada pada halaman login")
    public void onTheLoginPage() {
        loginPage.openUrl("https://www.saucedemo.com/");
        loginPage.validateOnLoginPage();
    }

    @When("User memasukkan valid username")
    public void inputValidUsername() {
        loginPage.inputUsername("standard_user");
    }

    @When("User memasukkan valid username yang beda")
    public void inputValidUsernameBeda() {
        loginPage.inputUsername("problem_user");
    }

    @When("User memasukkan invalid username")
    public void inputInvalidUsername () {
        loginPage.inputUsername("standardd_user");
    }

    @And("User memasukkan valid password")
    public void inputValidPassword() {
        loginPage.inputPassword("secret_sauce");
    }

    @And("User memasukkan invalid password")
    public void inputInvalidPassword() {
        loginPage.inputPassword("secret_saucee");
    }

    @And("User klik tombol login")
    public void clickLoginButton() {
        loginPage.clickLoginButton();
    }

    @Then("User berhasil login dan berada pada halaman produk")
    public void onTheProductPage() {
        productPage.validateOnProductPage();
    }

    @Then("User gagal login dan muncul pesan error")
    public void errorMessageisDisplayed(String message) {
        Assertions.assertTrue(loginPage.validateErrorMessageIsDisplayed());
        Assertions.assertTrue(loginPage.validateEqualErrorMessage(message));

    }

}
