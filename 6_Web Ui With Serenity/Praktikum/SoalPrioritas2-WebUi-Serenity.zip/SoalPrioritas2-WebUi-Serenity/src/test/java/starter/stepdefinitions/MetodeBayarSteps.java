package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.MetodeBayarPage;

public class MetodeBayarSteps {

    @Steps
    MetodeBayarPage metodeBayarPage;

    @Given("User sudah memilih produk dan diarahkan ke halaman pembayaran")
    public void goToPaymentPage() {
        metodeBayarPage.validateToPaymentPage();
    }

    @When("User berada pada halaman pembayaran")
    public void onThePaymentPage() {
        metodeBayarPage.openUrl("https://www.sepulsa.com/transaction/checkout");
    }

    @And("User klik metode pembayaran")
    public void choosePaymentMethod() {
        metodeBayarPage.choosePaymentMethod();
    }

    @And("User tidak memilih metode pembayaran")
    public void chooseInvalidPaymentMethod() {
        metodeBayarPage.chooseInvalidPaymentMethod();
    }

    @Then("Proses pembayaran sukses")
    public void PaymentSuccess() {
        metodeBayarPage.paymentSuccess();
    }

    @Then("Pembayaran gagal dan muncul pesan error")
    public void errorMessageisDisplayed(String message) {
        Assertions.assertTrue(metodeBayarPage.validateErrorMessageIsDisplayed());
    }
}
