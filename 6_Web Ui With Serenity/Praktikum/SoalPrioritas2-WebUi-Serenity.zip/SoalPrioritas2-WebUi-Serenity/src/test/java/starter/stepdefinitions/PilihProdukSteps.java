package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.MenuPage;
import starter.pages.PilihProdukPage;

import java.awt.*;

public class PilihProdukSteps {

    @Steps
    PilihProdukPage pilihProdukPage;

    @Steps
    MenuPage menuPage;

    @Given("User telah login dengan valid dan berada pada halaman menu")
    public void onTheLoginPage() {
        pilihProdukPage.openUrl("https://www.sepulsa.com/menu");
        pilihProdukPage.validateOnMenuPage();
    }

    @When("User memilih fitur pilih produk")
    public void chooseProduct() {
        pilihProdukPage.inputChooseProduct("chooseProduct");
    }

    @And("User melihat dan mengisi detail produk")
    public void fillProductDetail() {
        pilihProdukPage.inputProductDetail("phone_number");
    }

    @Then("User melanjutkan ke tahap pembayaran")
    public void goToPurchaseStep() {
        pilihProdukPage.validateToPurchaseStep();
    }

    @Then("Muncul pesan error karena produk tidak tersedia")
    public void errorMessageisDisplayed(String message) {
        Assertions.assertTrue(pilihProdukPage.validateErrorMessageIsDisplayed());
    }
}
