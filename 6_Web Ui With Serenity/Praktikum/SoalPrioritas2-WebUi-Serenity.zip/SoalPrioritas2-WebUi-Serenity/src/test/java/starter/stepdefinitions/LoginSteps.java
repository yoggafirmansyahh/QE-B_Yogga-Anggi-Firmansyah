package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.jupiter.api.Assertions;
import starter.pages.DashboardPage;
import starter.pages.LoginPage;

public class LoginSteps {

    @Steps
    LoginPage loginPage;

    @Steps
    DashboardPage dashboardPage;

    @Given("User berada pada halaman login")
    public void onTheLoginPage() {
        loginPage.openUrl("https://www.sepulsa.com/signin");
        loginPage.validateOnLoginPage();
    }

    @When("User memasukkan valid username")
    public void inputValidUsername() {
        loginPage.inputUsername("username");
    }

    @When("User memasukkan invalid username")
    public void inputInvalidUsername() {
        loginPage.inputInvalidPassword("passwordd");
    }

    @And("User memasukkan valid password")
    public void inputValidPassword() {
        loginPage.inputPassword("password");

    }
    @And("User memasukkan invalid password")
    public void inputInvalidPassword() {
        loginPage.inputInvalidPassword("invalid password");
    }
    @And("User klik tombol login")
    public void clickLoginButton() {
        loginPage.clickLoginButton();
    }

    @Then("User berhasil login dan berada pada halaman utama")
    public void onTheDashboardPage() {
        dashboardPage.validateOnDashboardPage();
    }

    @Then("User gagal login dan muncul pesan error")
    public void errorMessageisDisplayed(String message) {
        Assertions.assertTrue(loginPage.validateErrorMessageIsDisplayed());
        Assertions.assertTrue(loginPage.validateEqualErrorMessage(message));
    }
}
