package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class DashboardPage extends PageObject {

    private By messageid() {
        return By.className("Halo Selamat Datang Kembali");
    }
    @Step
    public boolean validateOnDashboardPage() {
        return $(messageid()).isDisplayed();
    }

}
