package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class MetodeBayarPage extends PageObject {

    private By title() {
        return By.className("Pembayaran");}

    private By methodButton() {
        return By.id("label Gopay");}

    private By errorMessage() {
        return By.id("error_select_payment");
    }

    @Step
    public boolean validateToPaymentPage() {
        return $(title()).isDisplayed();
    }

    @Step
    public void choosePaymentMethod() {
        $(methodButton()).click();
    }

    @Step
    public void chooseInvalidPaymentMethod() {
        $(methodButton()).click();
    }
    @Step
    public boolean paymentSuccess() {
        return $(title()).isDisplayed();
    }

    @Step
    public boolean validateErrorMessageIsDisplayed() {
        return $(errorMessage()).isDisplayed();
    }



}
