package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class PilihProdukPage extends PageObject {

    private By menuTitle() {
        return By.id("Semua_Produk");
    }

    private By chooseProductField() {
        return By.id("choose_product");
    }

    private By inputProductDetailField() {
        return By.id("phone_number");
    }

    private By purchaseStep() {
        return By.id("Pembayaran");
    }

    private By errorMessage() {
        return By.xpath("//h3[@data-test='error'");
    }

    @Step
    public void inputChooseProduct(String chooseProduct) {
        $(chooseProductField()).type(chooseProduct);
    }

    @Step
    public void inputProductDetail(String productdetail) {
        $(inputProductDetailField()).type(productdetail);
    }
    @Step
    public boolean validateOnMenuPage() {
        return $(menuTitle()).isDisplayed();
    }

    @Step
    public boolean validateToPurchaseStep() {
        return $(purchaseStep()).isDisplayed();
    }

    @Step
    public boolean validateErrorMessageIsDisplayed() {
        return $(errorMessage()).isDisplayed();
    }
}
