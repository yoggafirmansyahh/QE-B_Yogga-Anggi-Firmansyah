import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyStepdefs {
    @Given("user send request untuk mengakses fitur cart")
    public void userSendRequestUntukMengaksesFiturCart() {
    }

    @When("user send request dengan method POST untuk menambahkan produk ke keranjang")
    public void userSendRequestDenganMethodPOSTUntukMenambahkanProdukKeKeranjang() {
    }

    @Then("muncul status code sesuai menandakan produk telah ditambahkan")
    public void munculStatusCodeSesuaiMenandakanProdukTelahDitambahkan() {
    }

    @And("produk berhasil ditambahkan")
    public void produkBerhasilDitambahkan() {
    }

    @Given("user send request untuk login dengan endpoint yang salah")
    public void userSendRequestUntukLoginDenganEndpointYangSalah() {
    }

    @When("user send request dengan method POST dengan endpoint yang salah")
    public void userSendRequestDenganMethodPOSTDenganEndpointYangSalah() {
    }

    @Then("muncul status code {int} yang menandakan error")
    public void munculStatusCodeYangMenandakanError(int arg0) {
    }

    @And("user gagal login dengan valid dan muncul pesan error")
    public void userGagalLoginDenganValidDanMunculPesanError() {
    }

    @Given("user send request untuk login dengan valid")
    public void userSendRequestUntukLoginDenganValid() {
    }

    @Given("user send request untuk dapat melakukan update pada produk yang sudah ada pada cart")
    public void userSendRequestUntukDapatMelakukanUpdatePadaProdukYangSudahAdaPadaCart() {
    }

    @When("user send request dengan method PUT untuk mengupdate data")
    public void userSendRequestDenganMethodPUTUntukMengupdateData() {
    }

    @Then("muncul status code sesuai untuk mengupdate data produk")
    public void munculStatusCodeSesuaiUntukMengupdateDataProduk() {
    }

    @And("user berhasil melakukan update pada data di dalam cart")
    public void userBerhasilMelakukanUpdatePadaDataDiDalamCart() {
    }

    @Given("user send request untuk dapat melakukan penghapusan produk pada cart")
    public void userSendRequestUntukDapatMelakukanPenghapusanProdukPadaCart() {
    }

    @When("user send request dengan method DELETE untuk menghapus data")
    public void userSendRequestDenganMethodDELETEUntukMenghapusData() {
    }

    @Then("muncul status code sesuai untuk menghapus data produk")
    public void munculStatusCodeSesuaiUntukMenghapusDataProduk() {
    }

    @And("user berhasil melakukan delete pada data di dalam cart")
    public void userBerhasilMelakukanDeletePadaDataDiDalamCart() {
    }

    @When("user send request dengan method POST untuk dapat login")
    public void userSendRequestDenganMethodPOSTUntukDapatLogin() {

    }

    @When("user send request dengan endpoint yang valid untuk mengakses informasi produk")
    public void userSendRequestDenganEndpointYangValidUntukMengaksesInformasiProduk() {

    }

    @Given("user send request untuk mengakses informasi produk dengan valid")
    public void userSendRequestUntukMengaksesInformasiProdukDenganValid() {
    }

    @Then("muncul status code sesuai untuk menampilkan semua informasi produk")
    public void munculStatusCodeSesuaiUntukMenampilkanSemuaInformasiProduk() {
    }

    @And("semua informasi produk berhasil ditampikan")
    public void semuaInformasiProdukBerhasilDitampikan() {
    }

    @Given("user send request untuk dapat melakukan update pada data produk")
    public void userSendRequestUntukDapatMelakukanUpdatePadaDataProduk() {
    }

    @When("user send request dengan method POST untuk mengupdate data")
    public void userSendRequestDenganMethodPOSTUntukMengupdateData() {
    }

    @Then("muncul status code sesuai setelah mengupdate data informasi tentang produk")
    public void munculStatusCodeSesuaiSetelahMengupdateDataInformasiTentangProduk() {
    }

    @And("user berhasil melakukan update mengenai data informasi produk")
    public void userBerhasilMelakukanUpdateMengenaiDataInformasiProduk() {
    }

    @Given("user send request untuk dapat melakukan penghapusan produk pada database")
    public void userSendRequestUntukDapatMelakukanPenghapusanProdukPadaDatabase() {
    }

    @When("user send request dengan method DELETE untuk menghapus data dengan endpoint yang benar")
    public void userSendRequestDenganMethodDELETEUntukMenghapusDataDenganEndpointYangBenar() {
    }

    @Then("muncul status code sesuai setelah menghapus data informasi produk")
    public void munculStatusCodeSesuaiSetelahMenghapusDataInformasiProduk() {
    }

    @And("user berhasil menghapus data pada produk tertentu")
    public void userBerhasilMenghapusDataPadaProdukTertentu() {
    }

    @Given("user send request untuk membuat akun baru")
    public void userSendRequestUntukMembuatAkunBaru() {
    }

    @When("user send request untuk membuat akun baru dengan email dan password yang belum terdaftar")
    public void userSendRequestUntukMembuatAkunBaruDenganEmailDanPasswordYangBelumTerdaftar() {
    }

    @Then("muncul status code sesuai yaitu {int} yang menandakan created")
    public void munculStatusCodeSesuaiYaituYangMenandakanCreated(int arg0) {
    }

    @And("akun berhasil dibuat")
    public void akunBerhasilDibuat() {
    }

    @Given("user mencoba untuk menghapus data user yang tidak ada pada database")
    public void userMencobaUntukMenghapusDataUserYangTidakAdaPadaDatabase() {
    }

    @When("user send request dengan method DELETE untuk menghapus data pada database")
    public void userSendRequestDenganMethodDELETEUntukMenghapusDataPadaDatabase() {
    }

    @Then("muncul status code sesuai yaitu {int} setelah mencoba menghapus data yang tidak ada")
    public void munculStatusCodeSesuaiYaituSetelahMencobaMenghapusDataYangTidakAda(int arg0) {
    }

    @And("user tidak dapat menghapus data yang tidak ada dan tidak ada data yang terhapus")
    public void userTidakDapatMenghapusDataYangTidakAdaDanTidakAdaDataYangTerhapus() {
    }

    @Then("muncul status code sesuai yaitu {int}")
    public void munculStatusCodeSesuaiYaitu(int arg0) {
    }

    @And("user telah login dengan valid")
    public void userTelahLoginDenganValid() {
    }
}
