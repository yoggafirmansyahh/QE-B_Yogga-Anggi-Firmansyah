package starter.user;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Step;

public class Login {

    public Login(Response response) {
    }

    @Given("user memiliki akses ke API JSONPlaceholder")
    public void user_has_access_to_JSONPlaceholder_API() {
        RestAssured.baseURI = "https://fakestoreapi.com/auth/login";
    }

    @When("user melakukan request POST untuk login")
    public void user_makes_POST_request_for_login() {
        sendLoginRequest("user123", "password123");
    }

    @Then("muncul status code sesuai yaitu {int}")
    public void verify_status_code(int expectedStatusCode) {
        verifyStatusCode(expectedStatusCode);
    }

    @And("user telah login dengan valid")
    public void verify_successful_login() {
        verifySuccessfulLogin();
    }

    @When("user melakukan request POST untuk login dengan endpoint yang salah")
    public void user_makes_POST_request_with_invalid_endpoint() {
        sendLoginRequestWithInvalidEndpoint();
    }

    @Then("muncul status code 400 yang menandakan error")
    public void verify_bad_request_status_code() {
        verifyStatusCode(400);
    }

    @And("user gagal login dengan valid dan muncul pesan error")
    public void verify_failed_login_with_error_message() {
        verifyFailedLoginWithError();
    }
    @Step
    private void sendLoginRequest(String username, String password) {

    }
    @Step
    private void sendLoginRequestWithInvalidEndpoint() {

    }
    @Step
    private void verifyStatusCode(int expectedStatusCode) {

    }
    @Step
    private void verifySuccessfulLogin() {

    }
    @Step
    private void verifyFailedLoginWithError() {

    }
    private class Response {
    }

    private static class RestAssured {
        public static String baseURI;
    }
}
