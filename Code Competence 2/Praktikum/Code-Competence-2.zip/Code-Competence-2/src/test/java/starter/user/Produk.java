package starter.user;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Step;

public class Produk {

    private Response response;

    @Given("user send request untuk mengakses informasi produk dengan valid")
    public void user_sends_request_to_access_product_info() {
        RestAssured.baseURI = "https://fakestoreapi.com/products";
    }

    @When("user send request dengan endpoint yang valid untuk mengakses informasi produk")
    public void user_makes_request_to_get_product_info() {
        sendGetProductInfoRequest();
    }

    @Then("muncul status code sesuai untuk menampilkan semua informasi produk")
    public void verify_status_code_for_product_info() {
        verifyStatusCode(200);
    }

    @Then("semua informasi produk berhasil ditampilkan")
    public void verify_product_info_displayed_successfully() {
        verifyProductInfoDisplayed();
    }

    @Given("user send request untuk dapat melakukan update pada data produk")
    public void user_sends_request_to_update_product_info() {
        RestAssured.baseURI = "https://fakestoreapi.com/products/7";
    }

    @When("user send request dengan method POST untuk mengupdate data")
    public void user_makes_POST_request_to_update_product_info() {
        sendUpdateProductInfoRequest();
    }

    @Then("muncul status code sesuai setelah mengupdate data informasi tentang produk")
    public void verify_status_code_for_product_info_update() {
        verifyStatusCode(200);
    }

    @Then("user berhasil melakukan update mengenai data informasi produk")
    public void verify_product_info_updated_successfully() {
        verifyProductInfoUpdated();
    }

    @Given("user send request untuk dapat melakukan penghapusan produk pada database")
    public void user_sends_request_to_delete_product_info() {
        RestAssured.baseURI = "https://fakestoreapi.com/products/6";
    }

    @When("user send request dengan method DELETE untuk menghapus data dengan endpoint yang benar")
    public void user_makes_DELETE_request_to_delete_product_info() {
        sendDeleteProductInfoRequest();
    }

    @Then("muncul status code sesuai setelah menghapus data informasi produk")
    public void verify_status_code_for_product_info_delete() {
        verifyStatusCode(200);
    }

    @Then("user berhasil menghapus data pada produk tertentu")
    public void verify_product_info_deleted_successfully() {
        verifyProductInfoDeleted();
    }

    @Step
    private void sendGetProductInfoRequest() {
    }

    @Step
    private void sendUpdateProductInfoRequest() {
    }

    @Step
    private void sendDeleteProductInfoRequest() {
    }

    @Step
    private void verifyStatusCode(int expectedStatusCode) {
    }

    @Step
    private void verifyProductInfoDisplayed() {
    }

    @Step
    private void verifyProductInfoUpdated() {
    }

    @Step
    private void verifyProductInfoDeleted() {
    }

    private class Response {
    }

    private class RestAssured {
        public static String baseURI;
    }
}

