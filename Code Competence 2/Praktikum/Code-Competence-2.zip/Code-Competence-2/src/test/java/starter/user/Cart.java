package starter.user;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;

public class Cart {

    private Response response;

    @Given("user send request untuk mengakses fitur cart")
    public void user_sends_request_to_access_cart_feature() {
        RestAssured.baseURI = "https://fakestoreapi.com/carts";
    }

    @When("user send request dengan method POST untuk menambahkan produk ke keranjang")
    public void user_makes_POST_request_to_add_product_to_cart() {
        sendAddToCartRequest("product123");
    }

    @Then("muncul status code sesuai menandakan produk telah ditambahkan")
    public void verify_status_code_for_product_added() {
        verifyStatusCode(200);
    }

    @And("produk berhasil ditambahkan")
    public void verify_product_added_successfully() {
        verifyProductAdded();
    }

    @When("user send request untuk dapat melakukan update pada produk yang sudah ada pada cart")
    public void user_makes_PUT_request_to_update_product_in_cart() {
        sendUpdateCartRequest("product123");
    }

    @Then("muncul status code sesuai untuk mengupdate data produk")
    public void verify_status_code_for_product_updated() {
        verifyStatusCode(200);
    }

    @And("user berhasil melakukan update pada data di dalam cart")
    public void verify_product_updated_successfully() {
        verifyProductUpdated();
    }

    @When("user send request untuk dapat melakukan penghapusan produk pada cart")
    public void user_makes_DELETE_request_to_remove_product_from_cart() {
        sendDeleteFromCartRequest("product123");
    }

    @Then("muncul status code sesuai untuk menghapus data produk")
    public void verify_status_code_for_product_deleted() {
        verifyStatusCode(200);
    }

    @And("user berhasil melakukan delete pada data di dalam cart")
    public void verify_product_deleted_successfully() {
        verifyProductDeleted();
    }

    @Step
    private void sendAddToCartRequest(String product) {
    }
    @Step
    private void sendUpdateCartRequest(String product) {
    }
    @Step
    private void sendDeleteFromCartRequest(String product) {
    }
    @Step
    private void verifyStatusCode(int expectedStatusCode) {
    }

    @Step
    private void verifyProductAdded() {
    }
    @Step
    private void verifyProductUpdated() {
    }
    @Step
    private void verifyProductDeleted() {
    }

    private class Response {
    }

    private static class RestAssured {
        public static String baseURI;
    }
}
