package starter.user;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Step;

public class User {

    private Response response;

    @Given("user send request untuk membuat akun baru")
    public void user_sends_request_to_create_new_account() {
        RestAssured.baseURI = "https://fakestoreapi.com/users";
    }

    @When("user send request untuk membuat akun baru dengan email dan password yang belum terdaftar")
    public void user_makes_request_to_create_new_account() {
        sendCreateAccountRequest("newuser@example.com", "newpassword123");
    }

    @Then("muncul status code sesuai yaitu {int} yang menandakan created")
    public void verify_status_code_for_account_creation(int expectedStatusCode) {
        verifyStatusCode(201);
    }

    @And("akun berhasil dibuat")
    public void verify_account_created_successfully() {
        verifyAccountCreated();
    }

    @Given("user mencoba untuk menghapus data user yang tidak ada pada database")
    public void user_attempts_to_delete_nonexistent_user_data() {
        RestAssured.baseURI = "https://fakestoreapi.com/users/6";
    }

    @When("user send request dengan method DELETE untuk menghapus data pada database")
    public void user_makes_DELETE_request_to_delete_user_data() {
        sendDeleteUserDataRequest("nonexistentuser");
    }

    @Then("muncul status code sesuai yaitu {int} setelah mencoba menghapus data yang tidak ada")
    public void verify_status_code_for_deleting_nonexistent_user_data(int expectedStatusCode) {
        verifyStatusCode(404);
    }

    @And("user tidak dapat menghapus data yang tidak ada dan tidak ada data yang terhapus")
    public void verify_failed_deletion_of_nonexistent_user_data() {
        verifyFailedDeletion();
    }

    @Step
    private void sendCreateAccountRequest(String email, String password) {
    }

    @Step
    private void sendDeleteUserDataRequest(String username) {
    }

    @Step
    private void verifyStatusCode(int expectedStatusCode) {
    }

    @Step
    private void verifyAccountCreated() {
    }

    @Step
    private void verifyFailedDeletion() {
    }

    private class Response {
    }

    private class RestAssured {
        public static String baseURI;
    }
}
