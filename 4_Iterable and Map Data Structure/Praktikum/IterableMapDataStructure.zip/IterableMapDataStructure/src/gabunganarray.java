import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class gabunganarray {
    public static void main(String[] args) {
        String[] input1Array1 = {"kazuya", "jin", "lee"};
        String[] input1Array2 = {"kazuya", "feng"};
        String[] result1 = mergeAndRemoveDuplicates(input1Array1, input1Array2);
        for (String name : result1) {
            System.out.print(name + " ");
        }
        // Output: kazuya jin lee feng

        String[] input2Array1 = {"lee", "jin"};
        String[] input2Array2 = {"kazuya", "panda"};
        String[] result2 = mergeAndRemoveDuplicates(input2Array1, input2Array2);
        for (String name : result2) {
            System.out.print(name + " ");
        }
        // Output: lee jin kazuya panda
    }

    public static String[] mergeAndRemoveDuplicates(String[] arr1, String[] arr2) {
        // Gabungkan kedua array
        List<String> mergedList = new ArrayList<>();
        for (String name : arr1) {
            mergedList.add(name);
        }
        for (String name : arr2) {
            if (!mergedList.contains(name)) {
                mergedList.add(name);
            }
        }

        // Konversi list menjadi array
        String[] resultArray = new String[mergedList.size()];
        resultArray = mergedList.toArray(resultArray);

        return resultArray;
    }
}
