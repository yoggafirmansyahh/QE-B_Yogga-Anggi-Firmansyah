package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class GetOrderbyID {

    @Step("user set API get order by ID")
    public String setAPIGetOrderByID() {
        String url = "https://altashop-api.fly.dev/api/";
        return url + "orders/12138";
    }

    @Step("user send request to get order by ID")
    public void requestGetOrderByID() {
        SerenityRest.given().get(setAPIGetOrderByID());
    }

    @Step("user receive status code for get order by ID")
    public void receiveStatusCodeGetOrderById() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("user receive an information of order based on ID")
    public void receiveInformationOrder() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_ORDER_BY_ID_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'ID'", equalTo(12138)));
        restAssuredThat(response -> response.body("'User'", notNullValue()));
        restAssuredThat(response -> response.body("'ID'", equalTo(25145)));
        restAssuredThat(response -> response.body("'Fullname'", notNullValue()));
        restAssuredThat(response -> response.body("'Email'", notNullValue()));
        restAssuredThat(response -> response.body("'Password'", equalTo(123123)));

        restAssuredThat(response -> response.body("'Product'", null));
        restAssuredThat(response -> response.body("'Quantity'", equalTo(1)));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
