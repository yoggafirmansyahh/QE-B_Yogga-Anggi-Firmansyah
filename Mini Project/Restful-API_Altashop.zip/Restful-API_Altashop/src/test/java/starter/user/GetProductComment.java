package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class GetProductComment {
    private static String url = "https://altashop-api.fly.dev/api/products/";

    @Step("user set API get all comment product")
    public String setAPICommentProduct() {
        return url + "2/comments";
    }

    @Step("user send request to get comment product")
    public void requestCommentProduct() {
        SerenityRest.given().get(setAPICommentProduct());
    }

    @Step("user receive an information of commented product")
    public void receiveCommentedProduct() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_COMMENT_PRODUCTS_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
