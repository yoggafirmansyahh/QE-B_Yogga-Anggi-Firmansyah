package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DeleteProduct {

    @Step("user set API delete product")
    public String setAPIEndpointDeleteProduct() {
        String url = "https://altashop-api.fly.dev/api/products/";
        return url + "1";
    }
    @Step("user send request to delete product")
    public void sendRequestDeleteProduct() {
        SerenityRest.given().delete(setAPIEndpointDeleteProduct());
    }
    @Step("user receive status code for deleted product")
    public void receiveStatusCodeDeleteProduct() {
        restAssuredThat(response -> response.statusCode(200));
    }
    @Step("product is deleted")
    public void productDeleted() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.DELETE_PRODUCT_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'data'", null));
        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
