package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class CreateNewOrder {

    @Step("user set API to create new order")
    public String setAPIEndpointCreateOrder() {
        String url = "https://altashop-api.fly.dev/api/";
        return url + "orders";
    }
    @Step("user send request to create new order")
    public void requestCreateNewOrder() {
        JSONObject requestbody = new JSONObject();

        requestbody.put("product_id","2");
        requestbody.put("quantity","1");


        SerenityRest.given()
                .header("Content-Type", "application/json")
                .body(requestbody.toString())
                .post(setAPIEndpointCreateOrder());
    }

    @Step("user receive status code for creating new order")
    public void receiveStatusCodeOrderCreated() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("new order was created")
    public void newOrderCreated() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.CREATE_NEW_ORDER_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'product_id'", equalTo("2")));
        restAssuredThat(response -> response.body("'quantity'", equalTo(("1"))));
        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
