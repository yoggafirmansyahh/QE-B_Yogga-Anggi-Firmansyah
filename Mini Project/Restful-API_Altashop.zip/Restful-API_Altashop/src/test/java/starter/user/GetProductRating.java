package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class GetProductRating {
    private static String url = "https://altashop-api.fly.dev/api/products/";

    @Step("user set API get product rating")
    public String setAPIGetProductRating() {
        return url + "1/ratings";
    }

    @Step("user send request to get product rating")
    public void requestGetProductRating() {
        JSONObject requestBody = new JSONObject();

        requestBody.put("data","4");

        SerenityRest.given()
                .header("Content-Type", "application/json")
                .body(requestBody.toString())
                .post(setAPIGetProductRating());
    }

    @Step("user receive a rating information of product")
    public void receiveProductRating() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_PRODUCT_RATING_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'data'", equalTo("4")));
        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
