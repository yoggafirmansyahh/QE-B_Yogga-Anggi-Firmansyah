package starter.user;

import jdk.dynalink.beans.StaticClass;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DeleteCategory {
    private static String url = "https://altashop-api.fly.dev/api/";

    @Step("user set API delete category")
    public String setAPIDeleteCategory() {
        return url + "categories/2";
    }

    @Step("user send request to delete category")
    public void requestDeleteCategory() {
        SerenityRest.given().delete(setAPIDeleteCategory());
    }

    @Step("user receive status code for deleted category")
    public void receiveStatusCodeDeleteCategory() {
        restAssuredThat(response -> response.statusCode(200));
    }
}
