package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;
import starter.utils.FileUtils;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.notNullValue;

public class Register {
    private static final String url = "https://altashop-api.fly.dev/api/auth/";

    @Step("user set API Endpoint to register page")
    public String setAPIEndpointRegister() {
        return url + "register";
    }

    @Step("user send request with a valid email and password to register")
    public void sendRequestValidRegister() {
        JSONObject requestBody = FileUtils.getUser();

        assert requestBody != null;
        SerenityRest.given()
                .header("Content-Type", "application/json")
                .body(requestBody.toString())
                .post(setAPIEndpointRegister());

    }

    @Step("user send request with registered email and password to register")
    public void sendRequestInvalidRegister() {
        JSONObject requestBody = FileUtils.getUser();

        assert requestBody != null;
        SerenityRest.given()
                .header("Content-Type", "application/json")
                .body(requestBody.toString())
                .post(setAPIEndpointRegister());
    }

    @Step("register success")
    public void registerSuccess() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.REGISTER_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'ID'", notNullValue()));
        restAssuredThat(response -> response.body("'Fullname'", notNullValue()));
        restAssuredThat(response -> response.body("'Email'", notNullValue()));
        restAssuredThat(response -> response.body("'Password'", notNullValue()));
        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }

    @Step("register failed and get error message")
    public void getErrorMessageRegister() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.REGISTER_INVALID_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'error'", notNullValue()));
        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}