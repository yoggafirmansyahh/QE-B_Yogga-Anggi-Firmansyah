package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class GetUserInformation {
    private static String url = "https://altashop-api.fly.dev/api/";

    @Step("user set API get user information")
    public String setAPIGetUserInformation() {
        return url + "auth/info";
    }

    @Step("user send request to get user information")
    public void requestGetUserInformation() {
        SerenityRest.given().get(setAPIGetUserInformation());
    }

    @Step("user receive status code 200 for get user information")
    public void receiveStatusCodeGetUserInformation() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("user receive an information of user")
    public void receiveUserInformation() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_USER_INFORMATION_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'ID'", equalTo(2)));
        restAssuredThat(response -> response.body("'Fullname'", equalTo("Firstname Lastname")));
        restAssuredThat(response -> response.body("'Email'", equalTo("someone@mail.com")));
        restAssuredThat(response -> response.body("'Password'", equalTo("123123")));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
