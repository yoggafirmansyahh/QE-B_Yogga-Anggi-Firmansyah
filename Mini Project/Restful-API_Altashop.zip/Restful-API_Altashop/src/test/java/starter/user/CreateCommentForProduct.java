package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class CreateCommentForProduct {

    @Step("user set API to comment for product")
    public String setAPICommentProduct() {
        String url = "https://altashop-api.fly.dev/api/products/";
        return url + "2/comments";
    }
    @Step("user send request to comment product")
    public void requestCommentProduct() {
        JSONObject requestbody = new JSONObject();

        requestbody.put("content","the games are great including Gran Turismo 7 but sadly GT4 is much better");

        SerenityRest.given()
                .header("Content-Type", "application/json")
                .body(requestbody.toString())
                .post(setAPICommentProduct());
    }

    @Step("user receive status code for comment product")
    public void receiveStatusCodeCommentProduct() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("product has commented")
    public void productCommented() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.CREATE_COMMENT_PRODUCT_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'ID'", equalTo("1")));
        restAssuredThat(response -> response.body("'Content'", equalTo(("the games are great including Gran Turismo 7 but sadly GT4 is much better"))));
        restAssuredThat(response -> response.body("'User'", equalTo("null")));
        restAssuredThat(response -> response.body("'Product'", equalTo("null")));
        restAssuredThat(response -> response.body("'Comment'", equalTo("null")));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
