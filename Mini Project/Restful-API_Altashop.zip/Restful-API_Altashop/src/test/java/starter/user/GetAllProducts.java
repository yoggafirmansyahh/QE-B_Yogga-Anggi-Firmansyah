package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class GetAllProducts {

    @Step("user set API get all products")
    public String setAPIGetAllProducts() {
        String url = "https://altashop-api.fly.dev/api/";
        return url + "products";
    }
    @Step("user send request to get all products")
    public void requestGetAllProducts() {
        SerenityRest.given().get(setAPIGetAllProducts());
    }
    @Step("user receive an information of all products")
    public void receiveAllProducts() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_ALL_PRODUCTS_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
