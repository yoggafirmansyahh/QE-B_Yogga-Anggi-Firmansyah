package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class GetProductbyID {
    private static final String url = "https://altashop-api.fly.dev/api/products/";

    @Step("user set API get product by ID")
    public String setAPIEndpointGetProductbyID() {
        return url + "85525";
    }

    @Step("user send request to get product by ID")
    public void sendGetProductByIdRequest() {
        SerenityRest.given().get(setAPIEndpointGetProductbyID());
    }

    @Step("user receive status code 200 for get user by ID")
    public void receiveStatusCode200GetProductByID() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("user receive an information of product based on ID")
    public void receiveProductByID() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_PRODUCT_BY_ID_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'ID'", equalTo(85525)));
        restAssuredThat(response -> response.body("'Name'", notNullValue()));
        restAssuredThat(response -> response.body("'Description'", notNullValue()));
        restAssuredThat(response -> response.body("'Price'", equalTo(299)));
        restAssuredThat(response -> response.body("'Ratings'", equalTo(4)));
        restAssuredThat(response -> response.body("'Categories'", notNullValue()));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
