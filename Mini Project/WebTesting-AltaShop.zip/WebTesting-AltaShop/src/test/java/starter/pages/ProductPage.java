package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class ProductPage extends PageObject {
    private By title() {
        return By.className("title");
    }

    private By beliButton() {
        return By.className("v-btn__content");
    }

    private By cartCounter() {
        return By.className("v-badge__badge primary");
    }
    @Step
    public boolean validateOnProductPage() {
        return $(title()).isDisplayed();
    }

    @Step
    public boolean beliButtonIsDisplayed() {
        return $(beliButton()).isDisplayed();
    }

    @Step
    public void clickBeliButton() {
        $(beliButton()).click();
    }

    @Step
    public boolean validateCartCounterIsDisplayed() {
        return $(cartCounter()).isDisplayed();
    }
    @Step
    public boolean validateCartCounter() {
        return $(cartCounter()).getText().equals("1");
    }
}
