public class Alphabet {
    public static void main(String[] args) {
        String input = "SEPULSA OKE";
        String encryptedText = encrypt(input);
        System.out.println("Input: " + input);
        System.out.println("Output: " + encryptedText);
    }

    public static String encrypt(String text) {
        StringBuilder result = new StringBuilder();
        int shift = 10; // Pergeseran 10 urutan alphabet

        for (char character : text.toCharArray()) {
            if (Character.isLetter(character)) {
                char base = Character.isLowerCase(character) ? 'a' : 'A';
                char encryptedChar = (char) (((character - base + shift) % 26) + base);
                result.append(encryptedChar);
            } else {
                result.append(character); // Jika bukan huruf, biarkan tidak berubah
            }
        }

        return result.toString();
    }
}
