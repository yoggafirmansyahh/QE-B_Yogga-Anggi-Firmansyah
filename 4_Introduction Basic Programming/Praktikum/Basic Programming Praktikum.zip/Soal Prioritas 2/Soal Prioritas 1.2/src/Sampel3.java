import java.util.Scanner;

public class Sampel3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan harga jual : ");
        long hargajual = input.nextLong();

        System.out.print("Masukkan harga beli : ");
        long hargabeli = input.nextLong();

        //Menghitung Laba/Rugi = harga jual - harga beli
        long rugi = hargajual - hargabeli;

        System.out.println("Hasilnya sama saja");
    }
}
