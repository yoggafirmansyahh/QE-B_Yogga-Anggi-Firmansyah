import java.util.Scanner;

public class Sampel1 {
    // main method
    public static void main(String[] args) {

        // Menghitung Laba
        // Laba = harga jual - harga beli

        long jual = 30000;
        long beli = 15000;

        long Laba = jual - beli;

        System.out.println(Laba);



    }
}
