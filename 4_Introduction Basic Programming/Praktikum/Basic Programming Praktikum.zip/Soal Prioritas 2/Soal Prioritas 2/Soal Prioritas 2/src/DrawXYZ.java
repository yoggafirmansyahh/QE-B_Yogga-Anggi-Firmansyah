public class DrawXYZ {
    public static void drawXYZ(int height) {
        int i;
        for (i=1; i <= (height*5); i++) {
            for (int j = 1; j <= height; j++){
                if ((i+j - 1) % 3 == 0) {
                    System.out.print("X");
                }
                else if ((i+j) % 2 == 0) {
                    System.out.print("Y");
                }
                else{
                    System.out.print("Z");
                }
            }
            System.out.println();
            i += 4;
        }
    }

    public static void main(String[] args) {
        // Contoh pemanggilan fungsi dengan input 5
        drawXYZ(5);
    }
}
