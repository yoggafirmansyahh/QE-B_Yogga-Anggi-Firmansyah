
import java.util.Scanner;
public class SegitigaAsterik {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Input tinggi segitiga: ");
        int tinggi = input.nextInt();
        input.close();

        for (int i = 1; i <= tinggi; i++) {
            // Mencetak spasi untuk setiap baris
            for (int j = 1; j <= tinggi - i; j++) {
                System.out.print(" ");
            }

            // Mencetak asterisk untuk setiap baris
            for (int k = 1; k <= 2 * i - 1; k++) {
                System.out.print("*");
            }

            // Pindah ke baris baru
            System.out.println();
        }
    }
}

