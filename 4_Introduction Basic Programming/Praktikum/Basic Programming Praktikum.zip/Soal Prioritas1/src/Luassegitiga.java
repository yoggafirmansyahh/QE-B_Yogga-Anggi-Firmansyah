public class Luassegitiga {
    // main method
    public static void main(String[] args) {
        //Luas Segitiga
        //L = 0.5 x a x t
        double rumus = 0.5;
        int alas = 20;
        int tinggi = 25;

        double luas = rumus * alas * tinggi;

        System.out.println(luas);
    }
}
