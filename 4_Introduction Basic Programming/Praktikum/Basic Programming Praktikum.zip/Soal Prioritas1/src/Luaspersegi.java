public class Luaspersegi {
    // main method
    public static void main(String[] args) {

        // Luas persegi
        // L = p x t

        int panjang = 40;
        int lebar = 6;

        int Luas = panjang * lebar;

    System.out.println(Luas);
    }
}
