public class Luaslingkaran {
    // main method
    public static void main (String[] args) {

        //Luas lingkaran
        //L = phi x r x r

        double phi = 3.14;
        int r = 7;

        double luas = phi * r * r;
     System.out.println(luas);
    }
}
