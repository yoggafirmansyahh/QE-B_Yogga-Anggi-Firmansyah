package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class UpdateData {

    private static String url = "https://jsonplaceholder.typicode.com/posts/1";


    @Step("user memiliki akses ke API JSONPlaceholder untuk Update Data")
    public String setAPIEndpointUpdateData() {
        return url + "1";
    }
    @Step("user melakukan request PUT untuk Update Data")
    public void sendUpdateDataRequest() {
        JSONObject requestBody = new JSONObject();

        requestBody.put("userId","1");
        requestBody.put("id","1");

        SerenityRest.given()
                .header("Content-Type","application/json")
                .body(requestBody.toString())
                .put(setAPIEndpointUpdateData());
    }
    @Step("user menerima respons dengan kode status 200 untuk Update Data")
    public void getResponseCode200UpdateData() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("user harus menerima respons dengan kode status 404 untuk Update Data")
    public void getResponseCode404UpdateData() {
        restAssuredThat(response -> response.statusCode(404));
    }

    @Step("update berhasil")
    public void updateSuccess() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.UPDATE_USER_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'user'.'Id'", equalTo(1)));
        restAssuredThat(response -> response.body("'id','1'", equalTo(1)));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }

    @Step("data gagal diupdate")
    public void updateFailed() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.UPDATE_USER_INVALID_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'{}'",null));

        restAssuredThat((response -> response.body(matchesJsonSchema(schema))));

    }
}

