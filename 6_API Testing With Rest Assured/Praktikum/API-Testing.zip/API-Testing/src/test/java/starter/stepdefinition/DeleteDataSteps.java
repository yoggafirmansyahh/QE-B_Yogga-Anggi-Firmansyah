package starter.stepdefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.user.DeleteData;

public class DeleteDataSteps {

    @Steps
    DeleteData deleteData;

    @Given("user memiliki akses ke API JSONPlaceholder untuk hapus data")
    public void setAPIEndpointDeleteData() {
        deleteData.setAPIEndpointDeleteData();
    }

    @When("user melakukan request DELETE untuk hapus data")
    public void sendDeleteMethod() {
        deleteData.sendDeleteMethod();
    }

    @Then("user harus menerima respons dengan kode status 204 untuk hapus data")
    public void receiveStatusCode204DeleteData() {
        deleteData.receiveStatusCode204DeleteData();
    }

    @Then("user harus menerima respons dengan kode status 404 untuk hapus data")
    public void receiveStatusCode404DeleteData() {
        deleteData.receiveStatusCode404DeleteData();
    }

}
