package starter.user;

import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class NewDataPost {
    private static String url = "https://jsonplaceholder.typicode.com/posts";
    private ResponseAwareMatcher<Response> NullValueProvider;

    @Step("user memiliki akses ke API JSONPlaceholder untuk New Data Post")
    public String setAPIEndpointNewDataPost() {
        return url;
    }
    @Step("user melakukan request POST untuk New Data Post")
    public void getPostMethodNewDataPost() {
    }

    @Step("user harus menerima respons dengan kode status 201 untuk New Data Post")
    public void receiveResponseCode201NewDataPost() {
        restAssuredThat(response -> response.statusCode(201));
    }

    @Step("respons berisi data baru")
    public void newDataCreated() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.NEW_DATA_POST_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'user'.'Id'", equalTo(1)));
        restAssuredThat(response -> response.body("'id'", equalTo(1)));
        restAssuredThat(response -> response.body("'title'", notNullValue()));
        restAssuredThat(response -> response.body("'body", notNullValue()));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }

    @Step("user harus menerima respons dengan kode status 404 untuk New Data Post")
    public void receiveResponseCode404NewDataPost() {
        restAssuredThat(response -> response.statusCode(404));
    }

    @Step("data post baru gagal dibuat")
    public void newDataFailed() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.NEW_DATA_POST_INVALID_RESPONSE_SCHEMA);

        restAssuredThat(response ->
                response.body("'{}'", NullValueProvider));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }
}
