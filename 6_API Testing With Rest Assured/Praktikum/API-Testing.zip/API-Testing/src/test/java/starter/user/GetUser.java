package starter.user;


import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;
import starter.utils.JsonSchemaHelper;
import starter.utils.JsonSchema;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class GetUser {
    private static String url = "https://jsonplaceholder.typicode.com/posts";
    private ResponseAwareMatcher<Response> NullValueProvider;

    @Step("user memiliki akses ke API JSONPlaceholder")
    public String setAPIEndpointGetUser() {
        return url;
    }

    @Step("user melakukan request GET ke posts untuk Get User")
        public void sendGetRequestValidID() {
        SerenityRest.given().get(setAPIEndpointGetUser());
    }

    @Step("user melakukan request GET ke endpoint dengan ID yang tidak valid untuk Get User")
    public void getRequestInvalidID() {
        SerenityRest.given().get(setAPIEndpointGetUser());
    }

    @Step("user harus menerima respons dengan kode status 200 untuk Get User")
    public void receiveStatusCode200GetUser() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("user harus menerima respons dengan kode status 404 untuk Get User")
    public void receiveStatusCode404GetUser() {
        restAssuredThat(response -> response.statusCode(404));
    }

    @Step("data user berhasil didapatkan")
    public void dataFoundValidGetUser() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_USER_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'user'.'id'", equalTo(1)));
        restAssuredThat(response -> response.body("'id", equalTo(1)));
        restAssuredThat(response -> response.body("'title'", notNullValue()));
        restAssuredThat(response -> response.body("'body", notNullValue()));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }

    @Step("tidak ada data user yang ditemukan")
    public void dataNotFoundGetUser() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_USER_INVALID_RESPONSE_SCHEMA);

        restAssuredThat(response ->
            response.body("'{}'", NullValueProvider));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }

}