package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.user.UpdateData;

public class UpdateDataSteps {

    @Steps
    UpdateData updateData;

    @Given("user memiliki akses ke API JSONPlaceholder untuk Update Data")
    public void setAPIEndpointUpdateData() {
        updateData.setAPIEndpointUpdateData();
    }

    @When("user melakukan request PUT untuk Update Data")
    public void sendUpdateDataRequest() {
        updateData.sendUpdateDataRequest();
    }

    @Then("user menerima respons dengan kode status 200 untuk Update Data")
    public void getResponseCode200UpdateData() {
        updateData.getResponseCode200UpdateData();
    }

    @Then("user harus menerima respons dengan kode status 404 untuk Update Data")
    public void getResponseCode404UpdateData() {
        updateData.getResponseCode404UpdateData();
    }

    @And("update berhasil")
    public void updateSucces() {
        updateData.updateSuccess();
    }

    @And("data gagal diupdate")
    public void updateFailed() {
        updateData.updateFailed();
    }

}
