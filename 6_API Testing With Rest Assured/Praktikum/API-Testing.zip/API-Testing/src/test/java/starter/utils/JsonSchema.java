package starter.utils;

public class JsonSchema {
    public static final String GET_USER_RESPONSE_SCHEMA = "schema/get_user_schema.json";

    public static final String GET_USER_INVALID_RESPONSE_SCHEMA = "schema/get_user_invalid_schema.json";
    public static final String UPDATE_USER_RESPONSE_SCHEMA = "schema/update_user_schema.json";
    public static final String UPDATE_USER_INVALID_RESPONSE_SCHEMA = "schema/update_user_invalid_schema.json";

    public static final String GET_DATA_BY_ID_RESPONSE_SCHEMA = "schema/get_data_by_id_schema.json";
    public static final String GET_DATA_BY_ID_INVALID_RESPONSE_SCHEMA = "schema/get_data_by_id_invalid_schema.json";
    public static final String NEW_DATA_POST_RESPONSE_SCHEMA = "schema/new_data_post_invalid_schema.json";
    public static final String NEW_DATA_POST_INVALID_RESPONSE_SCHEMA = "schema/new_data_post_invalid_schema.json" ;
}