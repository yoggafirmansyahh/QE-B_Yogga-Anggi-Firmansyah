package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import starter.utils.JsonSchema;
import starter.utils.JsonSchemaHelper;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class GetDatabyID {
    private static String url = "https://jsonplaceholder.typicode.com/posts/1";


    @Step("user memiliki akses ke API JSONPlaceholder untuk Get Data by ID")
    public String setApiEndpointGetDatabyID() {
        return url + "1";
    }

    @Step("user melakukan request GET ke posts untuk Get Data by ID")
    public void sendGetRequestGetDataByID() {
        SerenityRest.given().get(setApiEndpointGetDatabyID());
    }

    @Step("user harus menerima respons dengan kode status 200 untuk Get Data by ID")
    public void getResponse200GetDataByID() {
        restAssuredThat(response -> response.statusCode(200));
    }

    @Step("user harus menerima respons dengan kode status 404 untuk Get Data by ID")
    public void getResponse404GetDataByID() {
        restAssuredThat(response -> response.statusCode(404));
    }

    @Step("respons harus berisi daftar postingan user sesuai ID")
    public void getDatabyIDSuccess() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_DATA_BY_ID_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'user'.'Id'", equalTo(1)));
        restAssuredThat(response -> response.body("'id'", equalTo(1)));

        restAssuredThat(response -> response.body(matchesJsonSchema(schema)));
    }

    @Step("data sesuai ID tidak muncul")
    public void invalidGetDatabyID() {
        JsonSchemaHelper helper = new JsonSchemaHelper();
        String schema = helper.getResponseSchema(JsonSchema.GET_DATA_BY_ID_INVALID_RESPONSE_SCHEMA);

        restAssuredThat(response -> response.body("'{}'",null));

        restAssuredThat((response -> response.body(matchesJsonSchema(schema))));
    }
}
