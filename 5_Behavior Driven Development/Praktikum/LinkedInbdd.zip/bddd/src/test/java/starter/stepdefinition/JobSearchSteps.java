package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class JobSearchSteps {

    @Given("User is on the LinkedIn homepage to search a job")
    public void onTheHomepage() {

    }

    @When("User clicks on the Jobs link")
    public void clickTheJobsLink() {

    }

    @And("User enters Software Engineer in the Search jobs field")
    public void enterTheSearchField() {

    }

    @And("User clicks on the Search button")
    public void clickTheSearchButton() {

    }

    @Then("User should see job listings related to Software Engineer")
    public void seeTheJobList() {

    }

}
