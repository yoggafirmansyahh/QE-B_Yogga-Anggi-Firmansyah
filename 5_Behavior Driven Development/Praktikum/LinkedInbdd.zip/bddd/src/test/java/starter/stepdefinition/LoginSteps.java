package starter.stepdefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {

    @Given("User is on the LinkedIn Login homepage")
    public void user_is_on_the_linked_in_login_homepage() {

    }


    @When("User clicks on the Sign in button")
    public void onTheSignInButton() {
}

    @Then("User should see the login page")
    public void seeTheLoginPage() {

    }

}
