package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class RegisterSteps {

    @Given("I am on the register page")
    public void onTheRegisterPage() {

    }

   @When("I enter valid username for regis")
    public void enterValidUsername() {

   }

   @And("I enter valid email for regis")
    public void enterValidEmail() {

   }

   @And("I enter valid password for regis")
    public void enterValidPassword() {

   }

    @And("I enter valid password confirmation")
    public void enterValidPasswordConfirm() {

    }

    @And("I click the register button")
    public void clickRegisterButton() {

    }

    @Then("I redirected to the Login page")
    public void goToLoginPage() {

    }

}
