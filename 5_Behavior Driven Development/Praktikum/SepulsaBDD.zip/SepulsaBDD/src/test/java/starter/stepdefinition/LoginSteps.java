package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {

    @Given("User is on the Sepulsa Login page")
    public void onTheLoginPage() {

    }

    @When("User fill the valid username")
    public void enterValidUsername() {

    }

    @And("User fill the valid password")
    public void enterValidPassword() {

    }

    @And("User click the login button")
    public void clickLoginButton() {

    }

    @Then("User should have login and redirected to homepage")
    public void LoginSuccessfully() {

    }
}
