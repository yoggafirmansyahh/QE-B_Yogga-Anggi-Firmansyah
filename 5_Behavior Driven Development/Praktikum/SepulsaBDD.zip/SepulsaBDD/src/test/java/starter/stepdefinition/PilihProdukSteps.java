package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PilihProdukSteps {

    @Given("User is on the Sepulsa homepage to choose product")
    public void onTheHomepage() {

    }

    @When("User clicks on the Products menu")
    public void clickProductMenu() {

    }

    @And("User selects the Mobile Top-Up category")
    public void selectMobileTopUp() {

    }

    @And("User selects a mobile operator")
    public void selectMobileOperator() {

    }

    @And("User enters a phone number")
    public void enterPhoneNumber() {

    }

    @And("User selects a top-up package")
    public void selectTopUpPackage() {

    }

    @And("User clicks on the Buy Now button")
    public void clickBuyButton() {

    }

    @Then("User should see the product added to the cart")
    public void ProductAddToTheCart() {

    }
}
