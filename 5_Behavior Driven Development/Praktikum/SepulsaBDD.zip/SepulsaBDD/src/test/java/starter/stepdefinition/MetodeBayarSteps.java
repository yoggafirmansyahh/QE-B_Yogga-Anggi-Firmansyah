package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MetodeBayarSteps {

    @Given("User is on the Sepulsa payment page")
    public void onThePaymentPage() {

    }

    @When("User selects a payment method")
    public void selectPaymentMethod() {

    }

    @And("User enters payment details")
    public void enterPaymentDetails() {

    }

    @And("User clicks on the Pay Now button")
    public void clickPayNow() {

    }

    @Then("User should see a payment success message")
    public void paymentSuccess() {

    }
}
