package starter.stepdefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.user.GetProductComment;

public class GetProductCommentSteps {

    @Steps
    GetProductComment getProductComment;

    @Given("user set API get all comment product")
    public void setAPIGetCommentProduct(){
        getProductComment.setAPICommentProduct();
    }

    @When("user send request to get comment product")
    public void requestGetCommentProduct() {
        getProductComment.requestCommentProduct();
    }

    @Then("user receive an information of commented product")
    public void receiveCommentedProduct() {
        getProductComment.receiveCommentedProduct();
    }
}
